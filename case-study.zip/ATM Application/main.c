/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int choice,balance,amount;
    printf("\n enter current balance:");
    scanf("%d",&balance);
    printf("\n 1.balance inquiry");
    printf("\n 2.cash withdrawal");
    printf("\n 3.cash deposit");
    printf("\n enter your choice:");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
        printf("\n Current balance:%d",balance);
        break;
        case 2:
        printf("\n enter withdrawal amount:");
        scanf("%d",&amount);
        if(amount<=balance)
        {
            balance=balance-amount;
        
          printf("\n Transaction successful");
          printf("\n Remaining balance :%d",balance);
        }
        else
          printf("\n Insufficient balance");
          break;
        case 3:  
        printf("\n enter deposit amount:");
        scanf("%d",&amount);
        balance = balance+amount;
        printf("\n Deposit successful");
          printf("\n Remaining balance :%d",balance);
          break;
          default:
          printf("\n Invalid Option");
    }
    

    return 0;
}