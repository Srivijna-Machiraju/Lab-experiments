/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  float distance,s,t;
  printf("\n enter speed :");
  scanf("%f",&s);
  printf("\n enter time :");
  scanf("%f",&t);
  distance = s*t;
    printf("\n Distance travelled = %f",distance);

    return 0;
}
