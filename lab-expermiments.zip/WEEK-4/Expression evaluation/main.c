/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int A,B,C,D,E,F,G,i,J;
    int a,b,c;
    printf("\n enter A,B,C,D,E,F,G :");
    scanf("%d%d%d%d%d%d%d",&A,&B,&C,&D,&E,&F,&G);
    a=A+B*C+(D*E)+F*G;
    printf("\n result of a is %d",a);
    b=A/B*C-B+A*D/3;
    printf("\n result of b is %d",b);
    c=A+++B---A;
    printf("\n result of c is %d",c);
    printf("\n enter the value of i :");
    scanf("%d",&i);
    J = (i++)+(++i);
    printf("\n result of J is %d",J);
    
    

    return 0;
}
