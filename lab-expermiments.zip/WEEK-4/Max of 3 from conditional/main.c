/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c;
    printf("\n enter a,b,c values :");
    scanf("%d%d%d",&a,&b,&c);
    (a>b && a>c)?printf("\n a is max"):((b>a && b>c)? printf("\n b is max"):printf("\n c is max"));
    

    return 0;
}
