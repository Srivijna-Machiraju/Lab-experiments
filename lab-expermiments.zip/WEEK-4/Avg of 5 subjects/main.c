/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int s1,s2,s3,s4,s5,tot;
    float avg;
    printf("\n enter subject 1,2,3,4,5 marks :");
    scanf("%d%d%d%d%d",&s1,&s2,&s3,&s4,&s5);
    tot=s1+s2+s3+s4+s5;
    printf("\n the total amrks is %d",tot);
    avg =(float)tot/5;
   printf("\n the average score is %f",avg);
    

    return 0;
}
