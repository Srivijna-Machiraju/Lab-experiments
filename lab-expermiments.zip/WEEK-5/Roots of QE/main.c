/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    float a,b,c,d,r1,r2;
    printf("\n enter a,b,c values:");
    scanf("%f%f%f",&a,&b,&c);
    d = b*b-4*a*c;
    if(d>0)
    {
        r1=(-b + sqrt(d))/(2*a);
        r2=(-b - sqrt(d))/(2*a);
        printf("\n Roots are %f and %f",r1,r2);
    }
    else if(d==0)
    {
        r1=-b/(2*a);
        printf("\n Roots are equal %f",r1);
    }
    else
    printf("\n Roots are imaginary");

    return 0;
}
