/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a,b;
    int choice;
    printf("\n enter a,b values:");
    scanf("%f%f",&a,&b);
    printf("\n 1.Addition");
    printf("\n 2.Subtraction");
    printf("\n 3.Multiplication");
    printf("\n 4.Division");
    printf("\n enter your choice:");
    scanf("%d",&choice);
    
    switch(choice)
    {
        case 1:
        printf("\n Result=%f",a+b);
        break;
        case 2:
        printf("\n Result=%f",a-b);
        break;
        case 3:
        printf("\n Result=%f",a*b);
        break;
        case 4:
          if(b==0)
          printf("Division by zero is not possible");
          else
          printf("\n Result=%f",a/b);
          break;
          default:
          printf("\n Invalid option");
    }

    return 0;
}
