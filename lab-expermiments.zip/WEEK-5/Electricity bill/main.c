/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int units;
    float bills;
    printf("\n enter units :");
    scanf("%d",&units);
    if(units<=100)
      bills=units*1.5;
    else
      if(units<=200)
        bills=units*2.5;
      else
         if(units<=500)
           bills=units*4;
         else
            bills=units*6;
    printf("\n Total electricity bill is %f",bills);        

    return 0;
}
