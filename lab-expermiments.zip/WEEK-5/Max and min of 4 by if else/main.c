/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1,n2,n3,n4,min1,min2,max1,max2;
    printf("\n enter n1,n2,n3,n4 values :");
    scanf("%d%d%d%d",&n1,&n2,&n3,&n4);
    if(n1>n2)
        {
            min1=n2;
            max1=n1;
        }
    else
        {
            min1=n1;
            max1=n2;
        }
    if(n3>n4)
        {
            min2=n4;
            max2=n3;
        }
    else
        {
            min2=n3;
            max2=n4;
        }
    if(min1<min2)
        printf("\n %d is minimum",min1);
    else
        printf("\n %d is minimum",min2);
    if(max1>max2)
        printf("\n %d is maximum",max1);
    else
        printf("\n %d is maximum",max2);

    return 0;
}
