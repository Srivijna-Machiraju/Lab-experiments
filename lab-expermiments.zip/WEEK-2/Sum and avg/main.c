/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int N1,N2,N3,sum;
    float avg;
    printf("\n enter numbers N1,N2 and N3: ");
    scanf("%d%d%d",&N1,&N2,&N3);
    sum = N1+N2+N3;
    printf("\n the sum is:%d",sum);
    avg=(float)sum/3;
    printf("\n the average is:%f",avg);

    return 0;
}
