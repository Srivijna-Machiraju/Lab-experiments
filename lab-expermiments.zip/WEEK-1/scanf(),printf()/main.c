/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    int b;
    int sum;
    printf("\n enter a value:");
    scanf("%d",&a);
    printf("\n enter b value:");
    scanf("%d",&b);
    sum = a+b;
    printf("\n Sum = %d",sum);

    return 0;
}
