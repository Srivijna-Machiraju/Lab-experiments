/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age,income,creditscore;
    printf("\n enter age:");
    scanf("%d",&age);
    printf("\n enter monthly income :");
    scanf("%d",&income);
    printf("\n enter credit score:");
    scanf("%d",&creditscore);
    if(age<21 || age>60)
       printf("\n Loan rejected:age not in 21 to 60");
    else if(income<25000)
       printf("\n Loan rejected:income below 25000");
    else if(creditscore<700)
       printf("\n Loan rejected:credit score less than 700");
    else
    printf("\n Loan approved");    


    return 0;
}
