/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int amount,type,discount,delivery,payment;
    printf("\n 0.Regular");
    printf("\n 1.Premium");
    printf("\n enter your membership type:");
    scanf("%d",&type);
    printf("\n enter your amount:");
    scanf("%d",&amount);
    if(amount>=500)
    delivery=0;
    else
    delivery=50;
    if(type==1)
    discount=(10*amount)/100;
    else 
    discount=0;
    payment=amount-discount+delivery;
    printf("\n the payable amount is %d",payment);
    

    return 0;
}
