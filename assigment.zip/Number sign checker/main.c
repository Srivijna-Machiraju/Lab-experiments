/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int number;
printf("\n enter number:");
scanf("%d",&number);

    if(number>0)
      printf("\n positive");
    else if (number<0)
      printf("\n negative");
    else
       printf("\n zero");    
    return 0;
}