/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m;
  printf("enter student marks:");
  scanf("%d",&m);
  if(m<0 || m>100)
  printf("\n Invalid mark");
  else
     if(m>=90)
     printf("\n O");
     else
        if(m>=80)
        printf("\n A+");
        else
           if(m>=70)
           printf("\n A");
           else
              if(m>=60)
              printf("\n B");
              else
                 if(m>=50)
                 printf("\n C");
                 else
                 printf("\n Fail");
        

    return 0;
}
