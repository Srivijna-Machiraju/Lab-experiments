/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float l;
    float b;
    float area;
    float perimeter;
    printf("\n enter l:");
    scanf("%f", &l);
    printf("\n enter b:");
    scanf("%f",&b);
    area = l*b;
    printf("Area =%f\n", area);
    perimeter = 2*(l+b);
    printf("Perimeter =%f\n", perimeter);

    return 0;
}