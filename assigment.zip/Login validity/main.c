/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int ID,password;
    printf("\n enter stored user ID:");
    scanf("%d",&ID);
    
    if(ID!=101)
       printf("\n User not found");
    else
    {
    printf("\n enter stored password :");
    scanf("%d",&password);
        if(password==4321)
        printf("\n Login successful");
        else
        printf("\n Incorrect password");
    }
    return 0;
}
