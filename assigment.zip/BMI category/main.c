/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
    float w,h,BMI;
    printf("\n enter weight(in kgs):");
    scanf("%f",&w);
    printf("\n enter height(in meters):");
    scanf("%f",&h);
    BMI= w/(pow(h,2));
    printf("\n BMI is %f",BMI);
    if(BMI>0 && BMI<18.5)
    printf("\n Underweight");
    else
       if(BMI<25)
       printf("\n Normal");
       else
          if(BMI<30)
          printf("\n Overweight");
          else
          printf("\n Obese");

    return 0;
}
